/* This file is auto generated, version 53 */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#53 Sun Oct 23 16:29:19 BRST 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "NAS"
#define LINUX_COMPILER "gcc version 4.8 (GCC) "
